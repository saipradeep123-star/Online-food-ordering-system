# Online Food Ordering System

A desktop food-ordering application built with **Python (PyQt5)** and **MySQL**.
Customers browse a categorised menu, build a cart and place orders; an administrator
manages the menu and categories. Developed as the mini project for
**21CSC205P – Database Management Systems** at SRM Institute of Science and Technology,
Kattankulathur (B.Tech CSE, specialization in Cyber Security, May 2025).

## Features

**Customer**
- Register / log in, or continue as a guest
- Browse menu items by category (tabbed view)
- Add items to a cart, change quantities, remove items
- Checkout with name and delivery address; order and line items are saved in MySQL
  inside a transaction (rolled back on failure)

**Administrator**
- Add, edit and delete menu items
- Add, edit and delete categories
- Safety checks: an item that appears in past orders, or a category that still contains
  items, cannot be deleted
- "Switch to Customer View" to preview the storefront

## Tech stack

| Layer | Technology |
|-------|------------|
| UI | PyQt5 |
| Database | MySQL 8 |
| DB driver | mysql-connector-python |
| Language | Python 3.8+ |

## Project structure

```
online-food-ordering-system/
├── README.md
├── LICENSE
├── requirements.txt
├── .env.example              # copy to .env and add your MySQL credentials
├── .gitignore
├── src/
│   ├── main.py               # entry point
│   └── food_ordering/
│       ├── config.py         # DB settings (from environment) + role constants
│       ├── database.py       # all SQL / data access, auto-creates schema + sample data
│       ├── auth.py           # login & registration dialogs
│       ├── customer.py       # menu tabs, cart, checkout
│       ├── admin.py          # admin panel, menu-item & category dialogs
│       └── main_window.py    # main window, login screen, role-based navigation
├── sql/
│   ├── schema.sql            # schema used by the application
│   ├── sample_data.sql      # sample menu + default admin
│   └── coursework/           # DBMS lab queries from the report (chapters 2, 3 and 5)
│       ├── 01_create_tables.sql
│       ├── 02_crud_operations.sql
│       ├── 03_constraints.sql
│       ├── 04_functions_joins_sets.sql
│       ├── 05_views.sql
│       ├── 06_triggers.sql
│       ├── 07_cursors.sql
│       └── 08_concurrency_recovery.sql
└── docs/
    ├── report/               # full project report (PDF)
    ├── diagrams/             # ER diagram, schema diagram
    ├── screenshots/          # application walkthrough screenshots
    └── normalization.md      # normalization demo (0NF → 5NF)
```

## Getting started

### 1. Prerequisites
- Python 3.8 or newer
- A running MySQL server (8.0+ recommended)

### 2. Install dependencies
```bash
git clone <your-repo-url>
cd online-food-ordering-system
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

### 3. Configure the database connection
```bash
cp .env.example .env             # Windows: copy .env.example .env
```
Edit `.env` and set `DB_PASSWORD` (and `DB_USER` / `DB_HOST` if they differ).

### 4. Run
```bash
python src/main.py
```
On first launch the app creates the `food_ordering_app` database, all tables, a sample
menu and a default admin account. (You can also load `sql/schema.sql` and
`sql/sample_data.sql` yourself.)

### Default login (demo only)

| Role | Username | Password |
|------|----------|----------|
| Admin | `admin` | `admin123` |

Customers can register from the login dialog, or use **Continue as Guest**.

## Database design

Application tables (see `sql/schema.sql`):

| Table | Purpose |
|-------|---------|
| `categories` | Menu categories (Appetizers, Main Course, …) |
| `menu_items` | Items with description, price and category (FK → `categories`) |
| `orders` | One row per order: customer name/address, total, status, timestamp |
| `order_items` | Line items of an order (FK → `orders`, `menu_items`), price captured at order time |
| `users` | Accounts with a `role` of `customer` or `admin` |

![ER diagram](docs/diagrams/er-diagram.png)
![Schema diagram](docs/diagrams/schema-diagram.png)

### DBMS coursework queries
`sql/coursework/` contains the constraints, joins, UNION, views, triggers, cursors,
transaction/locking and write-ahead-log examples from the report. They use a separate
`food_coursework` database so they never touch the application's data. Run them in
numerical order, e.g.:

```bash
mysql -u root -p < sql/coursework/01_create_tables.sql
mysql -u root -p < sql/coursework/02_crud_operations.sql
```

Some statements in the printed report referred to tables that do not exist in its own
schema or used non-MySQL syntax; those were corrected, and each correction is explained
in a comment at the top of the relevant file.

## Screenshots

| Login screen | Admin: delete item |
|---|---|
| ![Login](docs/screenshots/01-login-screen.png) | ![Delete](docs/screenshots/04-admin-delete-item-confirmation.png) |

| Admin: add item | Admin: edit price |
|---|---|
| ![Add](docs/screenshots/07-admin-add-menu-item.png) | ![Edit](docs/screenshots/09-admin-edit-item-price.png) |

More before/after database screenshots are in [`docs/screenshots/`](docs/screenshots/).

## Scope and known limitations

- The report's abstract describes inventory tracking, payment gateways, analytics and
  encrypted storage as goals; the implemented application covers the features listed
  above (menu, cart, orders, accounts, admin menu management).
- Passwords are stored **in plain text** and the admin account is seeded with a known
  password. This is acceptable for a classroom demo only. Before any real use, hash
  passwords (e.g. `bcrypt`) and remove the default admin.
- The "Remember me" checkbox on the login dialog is not wired up yet.
- Orders are saved, but there is no order-history or order-status screen yet
  (the admin panel has a placeholder comment for it).

## Documentation

- [Full project report (PDF)](docs/report/Online-Food-Ordering-System-Report.pdf)
- [Normalization notes](docs/normalization.md)

## Authors

- **B. Sai Pradeep Reddy** – RA2311030010315
- **Arun Krishna Devala** – RA2311030010320

Guided by **Dr. M. Siva Kumar**, Assistant Professor, Department of Networking and
Communications, SRM Institute of Science and Technology.

## License

Released under the [MIT License](LICENSE).
